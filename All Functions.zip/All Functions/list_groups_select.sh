#!/bin/bash

PS3="Choose the type of group view: "
options=("Short view (name and GID)" "Detailed view" "Cancel")

select choice in "${options[@]}"; do
    case "$choice" in
        "Short view (name and GID)")
            awk -F: '{print $1, $3}' /etc/group
            break
            ;;

        "Detailed view")
            cat /etc/group
            break
            ;;

        "Cancel")
            echo "Operation cancelled."
            break
            ;;

        *)
            echo "Invalid selection. Please try again."
            ;;
    esac
done
