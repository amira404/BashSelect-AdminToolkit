#!/bin/bash

read -p "Enter username to modify: " username


if getent passwd "$username" > /dev/null; then

    PS3="Select an attribute to modify: "
    options=("Rename user" "Update UID" "Add to existing group" "Change default shell")

    select choice in "${options[@]}" "Cancel"; do
        case $choice in

            "Rename user")
                read -p "Enter new username: " newname
                usermod -l "$newname" "$username"
                echo "Username has been changed to $newname."
                break
                ;;

            "Update UID")
                read -p "Enter new UID for $username: " new_uid
                usermod -u "$new_uid" "$username"
                echo "UID has been updated to $new_uid."
                break
                ;;

            "Add to existing group")
                read -p "Enter group name to add $username to: " groupname
                if getent group "$groupname" > /dev/null; then
                    usermod -aG "$groupname" "$username"
                    echo "$username has been added to group $groupname."
                    break
                else
                    echo "Group $groupname does not exist."
                fi
                ;;

            "Change default shell")
                read -p "Enter new shell path: " shellpath
                usermod -s "$shellpath" "$username"
                echo "$username now uses $shellpath as their shell."
                break
                ;;

            "Cancel")
                echo "No changes made."
                break
                ;;

            *)
                echo "Invalid selection. Try again."
                ;;
        esac
    done

else
    echo "User $username was not found."
fi
