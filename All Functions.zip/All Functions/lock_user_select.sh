#!/bin/bash

# Get all regular usernames (UID >= 1000 and < 65534)
user_list=($(awk -F: '$3 >= 1000 && $3 < 65534 {print $1}' /etc/passwd))

if [ ${#user_list[@]} -eq 0 ]; then
    echo "No regular users found to lock."
    exit 1
fi

echo "Select a user to lock:"
select selected_user in "${user_list[@]}" "Cancel"; do
    case "$selected_user" in
        "Cancel")
            echo "Operation cancelled."
            break
            ;;
        "")
            echo "Invalid selection. Try again."
            ;;
        *)
            if id "$selected_user" &> /dev/null; then
                usermod -L "$selected_user"
                echo "User '$selected_user' has been locked."
            else
                echo "User '$selected_user' does not exist."
            fi
            break
            ;;
    esac
done
