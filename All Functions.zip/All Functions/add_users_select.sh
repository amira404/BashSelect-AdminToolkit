#!/bin/bash

add_user() {
    read -p "Enter username: " username
    if id "$username" &>/dev/null; then
        echo "User '$username' already exists."
    else
        useradd "$username"
        read -s -p "Enter password: " pass
        echo
        echo "$username:$pass" | chpasswd
        echo "User '$username' has been created."
    fi
}

from_file() {
    read -p "Enter file path: " file
   while IFS=, read -r uname fname pass
do
    if id "$uname" &>/dev/null
    then
        echo "$uname already exists...generating a new name"
        uname=${uname}${RANDOM}
        echo new name is: $uname
    fi
    useradd -c "$fname" "$uname"
    echo $pass | passwd "$uname" --stdin
done < "$file"

}

mult_users() {

	echo Enter Username:
	read uname
	echo Enter Count: 
	read c
	echo Enter outputfile '(user credentials will be stored here)': 
	read out
	username=$uname

	for i in $(seq 1 $c)
	do
		if id "$uname" &>/dev/null
		then
			echo "$uname already exists...generating a new name"
			username=${uname}${RANDOM}
			echo new name is: $username
		fi

		useradd $username
		pass=$(openssl rand -base64 6)
		echo $pass | passwd $username --stdin
		echo "$username:$pass" >> credentials/$out
		echo "info_saved_for: $username" >> credentials/$out
	done
}

PS3="Choose a user creation method: "
options=("Add a single user" "Add users from file" "Add multiple users" "Cancel")

select option in "${options[@]}"; do
    case "$option" in
        "Add a single user")
            add_user
            break
            ;;
        "Add users from file")
            from_file
            break
            ;;
        "Add multiple users")
            mult_users
            break
            ;;
        "Cancel")
            echo "Operation cancelled."
            break
            ;;
        *)
            echo "Invalid option. Please try again."
            ;;
    esac
done
