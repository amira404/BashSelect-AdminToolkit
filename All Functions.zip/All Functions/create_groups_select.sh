#!/bin/bash

add_group() {
    read -p "Enter group name: " group
    if getent group "$group" > /dev/null; then
        echo "Group '$group' already exists!"
    else
        groupadd "$group"
        echo "Group '$group' added successfully."
    fi
}

from_file() {
    read -p "Enter file path: " file
    while IFS=, read -r group users; do
        if getent group "$group" > /dev/null; then
            echo "Group '$group' already exists. Adding users..."
        else
            groupadd "$group"
            echo "Created group '$group'. Adding users..."
        fi

        IFS=',' read -ra user_list <<< "$users"
        for user in "${user_list[@]}"; do
            if id "$user" &>/dev/null; then
                gpasswd -a "$user" "$group"
            else
                echo "User '$user' does not exist."
                new_user="${user}${RANDOM}"
                echo "Creating user '$new_user' with password '1234'"
                useradd "$new_user"
                echo "1234" | chpasswd
                gpasswd -a "$new_user" "$group"
            fi
        done
    done < "$file"
}

PS3="Choose group creation method: "
options=("Add a single group" "Add groups from file" "Cancel")

select choice in "${options[@]}"; do
    case "$choice" in
        "Add a single group")
            add_group
            break
            ;;
        "Add groups from file")
            from_file
            break
            ;;
        "Cancel")
            echo "Operation cancelled."
            break
            ;;
        *)
            echo "Invalid selection. Please try again."
            ;;
    esac
done
