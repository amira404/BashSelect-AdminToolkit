#!/bin/bash

# Get a list of regular users (UID >= 1000 and < 65534)
user_list=($(awk -F: '$3 >= 1000 && $3 < 65534 {print $1}' /etc/passwd))

if [ ${#user_list[@]} -eq 0 ]; then
    echo "No users found."
    exit 1
fi

echo "Select a user to change their password:"
select username in "${user_list[@]}" "Cancel"; do
    case "$username" in
        "Cancel")
            echo "Operation cancelled."
            break
            ;;
        "")
            echo "Invalid selection. Try again."
            ;;
        *)
            if id "$username" &>/dev/null; then
                read -s -p "Enter new password for $username: " password
                echo
                echo "$username:$password" | chpasswd
                echo "Password has been changed for user '$username'."
            else
                echo "User '$username' not found."
            fi
            break
            ;;
    esac
done
