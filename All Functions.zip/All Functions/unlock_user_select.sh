#!/bin/bash

# Get all users from /etc/passwd with UID >= 1000 (regular users only)
user_list=($(awk -F: '$3 >= 1000 && $3 < 65534 {print $1}' /etc/passwd))

# Check if we found any users
if [ ${#user_list[@]} -eq 0 ]; then
    echo " No regular users found to unlock."
    exit 1
fi

echo "Select a user to unlock:"
select selected_user in "${user_list[@]}" "Cancel"; do
    case $selected_user in
        "Cancel")
            echo "Operation cancelled."
            break
            ;;
        "")
            echo " Invalid choice. Please select a valid user number."
            ;;
        *)
            if passwd -S "$selected_user" | grep -q "L"; then
                sudo usermod -U "$selected_user"
                echo " User '$selected_user' has been unlocked successfully."
            else
                echo "User '$selected_user' is already unlocked."
            fi
            break
            ;;
    esac
done
