#!/bin/bash

read -p "Enter the group name to modify: " group_name

# Check if group exists
if getent group "$group_name" > /dev/null; then

    PS3="Choose the modification to perform: "
    options=("Rename group" "Change GID")

    select action in "${options[@]}" "Cancel"; do
        case "$action" in

            "Rename group")
                read -p "Enter the new group name: " new_group
                groupmod -n "$new_group" "$group_name"
                echo "Group has been renamed to $new_group."
                break
                ;;

            "Change GID")
                read -p "Enter the new GID: " new_gid
                groupmod -g "$new_gid" "$group_name"
                echo "Group ID has been changed to $new_gid."
                break
                ;;

            "Cancel")
                echo "Operation cancelled."
                break
                ;;

            *)
                echo "Invalid selection. Please choose a valid option."
                ;;
        esac
    done

else
    echo "Group '$group_name' not found."
fi
