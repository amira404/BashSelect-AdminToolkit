#!/bin/bash

PS3="Choose the type of user view: "
options=("Short view (usernames only)" "Detailed view" "Cancel")

select choice in "${options[@]}"; do
    case "$choice" in
        "Short view (usernames only)")
            awk -F: '{print $1}' /etc/passwd
            break
            ;;

        "Detailed view")
            cat /etc/passwd
            break
            ;;

        "Cancel")
            echo "Operation cancelled."
            break
            ;;

        *)
            echo "Invalid selection. Please try again."
            ;;
    esac
done
