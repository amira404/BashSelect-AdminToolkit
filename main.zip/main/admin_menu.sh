#!/bin/bash

if [ "$EUID" -ne 0 ]; then
    echo "This script must be run as sudo."
    exit 1
fi

echo "Welcome, Admin"
PS3="Select an option (1-10): "
options=(
    "Add a user"
    "Modify a user"
    "List all users"
    "Add a group"
    "Modify a group"
    "List all groups"
    "Lock a user account"
    "Unlock a user account"
    "Change user password"
    "Exit"
)

select opt in "${options[@]}"; do
    case "$opt" in
        "Add a user")             ./SelectFunctions/add_users_select.sh ;;
        "Modify a user")          ./SelectFunctions/modify_user_select.sh ;;
        "List all users")         ./SelectFunctions/list_users_select.sh ;;
        "Add a group")            ./SelectFunctions/add_groups_select.sh ;;
        "Modify a group")         ./SelectFunctions/modify_group_select.sh ;;
        "List all groups")        ./SelectFunctions/list_groups_select.sh ;;
        "Lock a user account")    ./SelectFunctions/lock_user_select.sh ;;
        "Unlock a user account")  ./SelectFunctions/unlock_user_select.sh ;;
        "Change user password")   ./SelectFunctions/change_password_select.sh ;;
        "Exit")                   exit 0 ;;
        *)                        echo "Invalid option. Try again." ;;
    esac
done
